// Hero3DTruck.jsx
// 3D Tesla Semi hero for United Services Recruiting.
//
// SETUP (run once in your project):
//   npm install three @react-three/fiber @react-three/drei
//
// FILE PLACEMENT:
//   - Put the model in your public folder:  public/models/tesla-semi.glb
//     (use tesla-semi.glb — the 348 KB optimized one. If it ever fails to
//      load, rename tesla-semi-web.glb to tesla-semi.glb instead.)
//   - Put this file in your components folder: src/components/Hero3DTruck.jsx
//
// USAGE:
//   import Hero3DTruck from "./components/Hero3DTruck";
//   <div style={{ position: "relative", height: "100vh" }}>
//     <Hero3DTruck />
//     {/* hero text / CTAs go on top with position:absolute + a higher zIndex */}
//   </div>

import { Suspense, useRef, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { useGLTF, Environment, ContactShadows, Float } from "@react-three/drei";
import * as THREE from "three";

const NAVY = "#16243B"; // brand navy

function TruckModel() {
  const group = useRef();
  // drei's useGLTF auto-handles the optimized (meshopt) file.
  const { scene } = useGLTF("/models/tesla-semi.glb");

  // This model already has real PBR materials (body, glass, lights, tires),
  // so we DON'T flatten everything to chrome. We just enhance reflections and
  // optionally tint the body — leaving glass/lights/tires looking correct.
  useEffect(() => {
    const TINT_NAVY = false; // set true to tint the truck body toward brand navy

    scene.traverse((o) => {
      if (!o.isMesh || !o.material) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];

      mats.forEach((m) => {
        m.envMapIntensity = 1.25; // pick up reflections from the environment
        o.castShadow = true;

        const name = (m.name || "").toLowerCase();

        if (name.includes("glass")) {
          // make windows read as glass
          m.transparent = true;
          m.opacity = 0.35;
          m.roughness = 0.05;
          m.metalness = 0.1;
        } else if (name.includes("light")) {
          // let the headlights/markers glow a little
          m.emissive = new THREE.Color("#fff6e0");
          m.emissiveIntensity = 0.6;
        } else if (TINT_NAVY && m.name === "Material" && m.color) {
          // body only
          m.color.lerp(new THREE.Color(NAVY), 0.4);
          m.metalness = 0.8;
          m.roughness = 0.3;
        }
      });
    });
  }, [scene]);

  // Slow auto-rotation + subtle mouse parallax.
  useFrame((state, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * 0.15;
    const tiltX = state.pointer.y * 0.08;
    const driftX = state.pointer.x * 0.25;
    group.current.rotation.x += (tiltX - group.current.rotation.x) * 0.05;
    group.current.position.x += (driftX - group.current.position.x) * 0.05;
  });

  return (
    <group ref={group} dispose={null}>
      {/* tweak scale/position to frame the truck against your hero text */}
      <primitive object={scene} scale={1.5} position={[0, -0.7, 0]} />
    </group>
  );
}

export default function Hero3DTruck() {
  return (
    <Canvas
      dpr={[1, 2]}
      camera={{ position: [4.5, 1.6, 6], fov: 38 }}
      gl={{ antialias: true, alpha: true }}
      style={{ position: "absolute", inset: 0 }}
    >
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 8, 5]} intensity={1.4} castShadow />
      <directionalLight position={[-6, 3, -4]} intensity={0.6} color="#4DA3FF" />

      <Suspense fallback={null}>
        <Float speed={1.2} rotationIntensity={0.15} floatIntensity={0.4}>
          <TruckModel />
        </Float>

        {/* reflections — try "city", "warehouse", "night", or "studio" */}
        <Environment preset="city" />

        <ContactShadows
          position={[0, -1.4, 0]}
          opacity={0.5}
          scale={14}
          blur={2.6}
          far={5}
          color="#000000"
        />
      </Suspense>
    </Canvas>
  );
}

useGLTF.preload("/models/tesla-semi.glb");
